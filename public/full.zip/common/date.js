// const dayofweek = new Date().getDay();


