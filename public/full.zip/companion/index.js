import { me as companion } from "companion";
import * as messaging from "messaging";
import weather from "weather";

function getWeather(x) {
  weather
    .getWeatherData()
    .then((data) => {
      if (data.locations.length > 0) {
        const temp = Math.floor(data.locations[0].currentWeather.temperature);
        const cond = data.locations[0].currentWeather.weatherCondition;
        const loc = data.locations[0].name;
        const unit = data.temperatureUnit;
        if (document.getElementById(`dl_${x + 1}`)) {
          document.getElementById(`dl_${x + 1}`).textContent = `${temp}\u00B0 ${unit}`;
        }
        if (messaging.peerSocket.readyState === messaging.peerSocket.OPEN) {
          messaging.peerSocket.send(`${temp}\u00B0 ${unit[0].toUpperCase()}`);
        } else {
          console.log('Cannot emit data from companion');
        }
        console.log(`It's ${temp}\u00B0 ${unit} and ${cond} in ${loc}`);
      }
    }).catch((ex) => {
      console.error(ex);
    });
}

if (companion.permissions.granted("access_location")) {
  messaging.peerSocket.addEventListener("open", (evt) => {
    setTimeout(() => {
      getWeather(1);
    }, 5000);
  });
} else {
  console.log('no permission to access location');
}