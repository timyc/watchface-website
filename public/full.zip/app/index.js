import clock from "clock";
import * as document from "document";
import { preferences } from "user-settings";
import * as util from "../common/utils";
import * as date from "../common/date";

import * as fs from "fs";
import { battery } from "power"; // import battery level (see line 51)
import { HeartRateSensor } from "heart-rate";
import { me as appbit } from "appbit";
import { week } from "user-activity";
import { today } from "user-activity";
import { battery } from "power";



// Update the clock every minute
clock.granularity = "minutes";

// Get a handle on the <text> element
const myLabel = document.getElementById("myLabel");
const batteryLabel = document.getElementById("batteryLabel");
const myDate = document.getElementById("myDate");
const dl_1 = document.getElementById("dl_1");
const dl_2 = document.getElementById("dl_2");
const dl_3 = document.getElementById("dl_3");
const dl_4 = document.getElementById("dl_4");

let dl_1_icon = document.getElementById("dl_1_icon");
let dl_2_icon = document.getElementById("dl_2_icon");
let dl_3_icon = document.getElementById("dl_3_icon");
let dl_4_icon = document.getElementById("dl_4_icon");




batteryLabel.text = (Math.floor(battery.chargeLevel) + "%").toString();




// --------------------------------------------------------------
// Display the date information 
let currentDate = new Date();
let cday = currentDate.getDate();
cdow = _weekday_(currentDate);
cmonth = _month_(currentDate);

let full_date = (cdow + ", " + cmonth + " "+ cday);
console.log(full_date);
myDate.text = full_date;



let currentDate = new Date();
let cdow = currentDate.getDay();
let cday = currentDate.getDate();
let cmonth = currentDate.getMonth() + 1;

function _weekday_(currentDate){
  let day = "";
  switch (currentDate.getDay()) {
      case 0:
        day = "Sunday";
        break;
      case 1:
        day = "Monday";
        break;
      case 2:
         day = "Tuesday";
        break;
      case 3:
        day = "Wednesday";
        break;
      case 4:
        day = "Thursday";
        console.log(day.toString())
        break;
      case 5:
        day = "Friday";
        break;
      case 6:
        day = "Saturday";
    }
  
  return day;
  
  
}

function _month_(currentDate){
  let month = "";
  switch (currentDate.getMonth()) {
      case 0:
        month = "Jan";
        break;
      case 1:
        month = "Feb";
        break;
      case 2:
         month = "Mar";
        break;
      case 3:
        month = "Apr";
        break;
      case 4:
        month = "May";
        break;
      case 5:
        month = "Jun";
        break;
      case 6:
        month = "Jul";
      case 7:
        month = "Aug";
      case 8:
        month = "Sep";
      case 9:
        month = "Oct";
      case 10:
        month = "Nov";
      case 11:
        month = "Dec";
        console.log(month.toString());

     
    }
  
  return month;
  
  
}

cdow = _weekday_(currentDate);
cmonth = _month_(currentDate);

// Everything above needs to be separated out into a date.js file but I'm just not sure how to do
// this at the moment
// --------------------------------------------------------------------------

// Time information

let retro_blue = document.getElementById('blue');
let retro_purple = document.getElementById('purple');
let background = document.getElementById("background_rect");


// Update the <text> element every tick with the current time
clock.ontick = (evt) => {
  let today = evt.date;
  let hours = today.getHours();
  if (preferences.clockDisplay === "12h") {
    // 12h format
    hours = hours % 12 || 12;
  } else {
    // 24h format
    hours = util.zeroPad(hours);
  }
  let mins = util.zeroPad(today.getMinutes());
  myLabel.text = `${hours}:${mins}`;
}



// -----------------------------------------------------------
  



let json_object  = fs.readFileSync("resources/config.json", "json");
if (fs.existsSync("resources/config.json")) {
  console.log("file exists!");

}


const dp_1 = json_object._dp_1_;

// ----------------------------------------------------------------------------------

// Defs folder for all data grabbing functions



// ---------------------------------------------------------------------------
function hrm_start(){
if (HeartRateSensor) {
  const hrm = new HeartRateSensor({ frequency: 1 });
  hrm.addEventListener("reading", () => {
    console.log(`Current heart rate: ${hrm.heartRate}`);
  });
  hrm.start();
}
}
// --------------------------------------------------------------------
function azm_start(){
if (appbit.permissions.granted("access_activity")) {
   console.log(`${week.adjusted.activeZoneMinutes} AZM`);
  //document.getElementById("dp1").text = 
}
}
// -------------------------------------------------------------------

function stp_start(){
if (appbit.permissions.granted("access_activity")) {
   console.log(`${today.adjusted.steps} Steps`);

}
}
// -----------------------------------------------------------------
function flr_start(){
if (appbit.permissions.granted("access_activity")) {
  if (today.local.elevationGain !== undefined) {
     console.log(`${today.adjusted.elevationGain} Floor(s)`);

   }
  
}
}
 


function _compa_(dp_read){
  let stat_var = "";
  switch (dp_read) {
      
    case "azm":
        stat_var = "azm";
        azm_start();
        break;
      
      case "stp":
        stat_var = "stp";
        stp_start();
        break;
      
      case "flr":
         stat_var = "flr";
         flr_start();
        break;
      
      case "hrm":
        stat_var = "hrm";
        hrm_start();
        break;
     
     
    }
  
  return stat_var;
  
  
}
// Functtion that takes in the json object, loops through the variable dps meaning data preferences. This then prints the dps
function dp_types(json_object){
  
  for ( const x of json_object._dps_) {
    
    console.log("dl_" + (json_object._dps_.indexOf(x)+1).toString());
    // console.log("dl_" + (json_object._dps_.indexOf(x)+1).toString()+"_"+"icon");
    console.log(x.toString());
    
    (("dl_" + (json_object._dps_.indexOf(x)+1).toString()+"_"+"icon")).href = ("resources/icons/"+ x.toString() + ".png");
    console.log("resources/icons/"+ x.toString() + ".png");
    
    
    
  }
  // json_object._dps_.forEach((element) => {
  //   // console.log(element.toString());
  // });
  
 

}


// batteryLabel.text = `Batt: ${batteryValue} %`; // the string including the batteryValue is being sent to the batteryHandle set at line 14


dp_types(json_object);

// Reading/making sense of the data
// -------------------------------------------------------------------------------------------------------------------
if (((json_object._theme_).toString() == "retro") && ((json_object._color_).toString() == "blue")){
    retro_blue.style.visibility = "visible";
    retro_purple.style.visibility = "hidden";
    // console.log("We is blue now");

  
    }

else {
    retro_blue.style.visibility = "hidden";
    retro_purple.style.visibility = "visible";
    // console.log("We is purple now");
  
    }



// switch((json_object._theme_).toString()){
    
//   case "retro":
    
    

// }
// Theme , color, layout, data

//let test_svg  = fs.readFileSync("resources/test.svg", "ascii");
//let svg_el = document.getElementById("test_svg");
//svg_el.new_test_file.style.visibility= "visible";
//let foreground = document.getElementById("foreground");
//foreground.href="test_svg";