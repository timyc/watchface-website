import clock from "clock";
import * as document from "document";
import { preferences } from "user-settings";
import * as util from "../common/utils";
import * as date from "../common/date";
import * as messaging from "messaging";
import sleep from "sleep";
import * as fs from "fs";
import { battery } from "power"; // import battery level (see line 51)
import { HeartRateSensor } from "heart-rate";
import { me as appbit } from "appbit";
import { week } from "user-activity";
import { today } from "user-activity";
import { battery } from "power";



// Update the clock every minute
clock.granularity = "minutes";

// Get a handle on the <text> element
const myLabel = document.getElementById("myLabel");
const batteryLabel = document.getElementById("batteryLabel");
const myDate = document.getElementById("myDate");
const dl_1 = document.getElementById("dl_1");
const dl_2 = document.getElementById("dl_2");
const dl_3 = document.getElementById("dl_3");
const dl_4 = document.getElementById("dl_4");

let dl_1_icon = document.getElementById("dl_1_icon");
let dl_2_icon = document.getElementById("dl_2_icon");
let dl_3_icon = document.getElementById("dl_3_icon");
let dl_4_icon = document.getElementById("dl_4_icon");




batteryLabel.text = (Math.floor(battery.chargeLevel) + "%").toString();




// --------------------------------------------------------------
// Display the date information 
let currentDate = new Date();
let cday = currentDate.getDate();
cdow = _weekday_(currentDate);
cmonth = _month_(currentDate);

let full_date = (cdow + ", " + cmonth + " "+ cday);
console.log(full_date);
myDate.text = full_date;



let cdow = currentDate.getDay();
let cmonth = currentDate.getMonth() + 1;

function _weekday_(currentDate){
  let day = "";
  switch (currentDate.getDay()) {
    case 0:
        day = "Sunday";
    break;
    case 1:
        day = "Monday";
    break;
    case 2:
         day = "Tuesday";
        break;
    case 3:
        day = "Wednesday";
        break;
    case 4:
        day = "Thursday";
        console.log(day.toString())
    break;
    case 5:
        day = "Friday";
        break;
    case 6:
        day = "Saturday";
    }
  
  return day;
  
  
}

function _month_(currentDate){
  let month = "";
  switch (currentDate.getMonth()) {
    case 0:
      month = "Jan";
      break;
    case 1:
      month = "Feb";
      break;
    case 2:
      month = "Mar";
      break;
    case 3:
      month = "Apr";
      break;
    case 4:
      month = "May";
      break;
    case 5:
      month = "Jun";
      break;
    case 6:
      month = "Jul";
      break;
    case 7:
      month = "Aug";
      break;
    case 8:
      month = "Sep";
      break;
    case 9:
      month = "Oct";
      break;
    case 10:
      month = "Nov";
      break;
    case 11:
      month = "Dec";
      break;
  }
  return month;
}

cdow = _weekday_(currentDate);
cmonth = _month_(currentDate);

// Everything above needs to be separated out into a date.js file but I'm just not sure how to do
// this at the moment
// --------------------------------------------------------------------------

// Time information

let !theme! = document.getElementById('!theme!Style');
let background = document.getElementById("background_rect");


// Update the <text> element every tick with the current time
clock.ontick = (evt) => {
  let today = evt.date;
  let hours = today.getHours();
  if (preferences.clockDisplay === "12h") {
    // 12h format
    hours = hours % 12 || 12;
  } else {
    // 24h format
    hours = util.zeroPad(hours);
  }
  let mins = util.zeroPad(today.getMinutes());
  myLabel.text = `${hours}:${mins}`;
}



// -----------------------------------------------------------
  



let json_object  = fs.readFileSync("resources/config.json", "json");
if (fs.existsSync("resources/config.json")) {
  console.log("file exists!");

}

// Defs folder for all data grabbing functions

function hrm_start(x) {
  if (HeartRateSensor) {
    const hrm = new HeartRateSensor({ frequency: 1 });
    hrm.addEventListener("reading", () => {
      document.getElementById(`dl_${x + 1}`).textContent = hrm.heartRate;
    });
    hrm.start();
  }
}

function azm_start(x) {
  if (appbit.permissions.granted("access_activity")) {
    document.getElementById(`dl_${x + 1}`).textContent = week.adjusted.activeZoneMinutes;
  }
}

function stp_start(x) {
  if (appbit.permissions.granted("access_activity")) {
    document.getElementById(`dl_${x + 1}`).textContent = today.adjusted.steps;
  }
}

function flr_start(x) {
  if (appbit.permissions.granted("access_activity")) {
    if (today.local.elevationGain !== undefined) {
      document.getElementById(`dl_${x + 1}`).textContent = today.adjusted.elevationGain;
    }
  }
}

function sleep_start(x) {
  if (!appbit.permissions.granted("access_sleep")) {
     console.log("no sleep permission");
  }
  if (sleep) {
    sleep.addEventListener("change", () => {
      document.getElementById(`dl_${x + 1}`).textContent = sleep.state;
    });
  } else {
    console.log('no sleep on this device');
  }
}

function calories_start(x) {
  if (appbit.permissions.granted("access_activity")) {
    document.getElementById(`dl_${x + 1}`).textContent = today.adjusted.calories;
  }
}

function distance_start(x) {
  if (appbit.permissions.granted("access_activity")) {
    document.getElementById(`dl_${x + 1}`).textContent = today.adjusted.distance;
  }
}

function weather_start(x) {
  document.getElementById(`dl_${x + 1}`).textContent = 'Loading...';
  messaging.peerSocket.addEventListener("message", (evt) => {
    document.getElementById(`dl_${x + 1}`).textContent = evt.data;
  });
}


/*
 * Bind selected stats
 */
for (let x = 0; x < json_object._dps_.length; x++) {
  switch(json_object._dps_[x].stat) {
    case 'sleep':
      sleep_start(x);
      break;
    case 'hrm':
      hrm_start(x);
      break;
    case 'spo2':
    case 'stp':
      stp_start(x);
      break;
    case 'calories':
      calories_start(x);
      break;
    case 'distance':
      distance_start(x);
      break;
    case 'azm':
      azm_start(x);
      break;
    case 'weather':
      weather_start(x);
      break;
    case 'flr':
      flr_start(x);
      break;
  }
}
